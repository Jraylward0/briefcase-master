# Operating systems and concurrency lab

This repository is provided to support an assignment in operating systems and concurrency. 
See the [module page](http://hesabu.net/en0572/#assessment) for more details.
